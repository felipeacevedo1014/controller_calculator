__app_name__ = "Trane Controller & Expansion Calculator"
__version__  = "1.3.0"   # <-- change this on every release